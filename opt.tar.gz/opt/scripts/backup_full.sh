#1/bin/bash
if [[ $# -ne 2 ]]; then
	echo "Error: Debes proporcionar ORIGEN y DESTINO."
	echo "Uso: $0 ORIGEN DESTINO"
	exit 1
fi

if [[ "$1" == "-help" ]]; then
	echo "Uso: $0 ORIGEN DESTINO"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

if [[ ! -d "$1" || ! -d "$2" ]]; then
	echo "Error: el origen o el destino no existen o no son directorios."
	exit 1
fi

FECHA-$(date +%Y%m%d)
DESTINO="$2/$(basename $1)_bkp_$FECHA.tar.gz"

tar -czf "$DESTINO" "$1"
